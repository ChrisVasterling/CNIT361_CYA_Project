/**
 * 
 * 
 */

var http = require('http');      // make API calls
var fsio = require("./fsio")     // Read, write, delete files


// A map of functions to a name so that a client name can be 
// provided on the client side.
var funcMap = {
    // clientName : apiName
    "lookupByZip" : lookupByZip,
    "lookupByName" : lookupByName,
    "getForecast" : getForecast, // Uses OneCall, limited to 1000/day
    "get35Forecast" : get35Forecast, 
    "getCurWeather" : getCurWeather
}


// API key for Open Weather Map
const API_ID = "2315a441a848091ada70be65e511f707";
// The minutely and daily limits of OpenWeather API. 
// Buffers are arbitrary to ensure staying under limits
const API_LIMITS = {
    onecall_minute : 2, // technically too much for 1000/day
    onecall_daily : 1000 - 20, // buffer of 20
    reg_minute : 60 - 5, // buffer of 5
    reg_daily : Math.floor(1000000 / 31) - 1000 // buffer of 1000 1000000 per month
}
// The current usage, load daily info at startup
var api_usage = {
    onecall_minute : 0,
    onecall_daily : 0,
    reg_minute : 0,
    reg_daily : 0,
}
var api_violations = {
    onecall_daily : false,
    onecall_minute : false,
    reg_daily : false,
    reg_minute : false
}

// Useful base URLs
var oneCallURL = "http://api.openweathermap.org/data/2.5/onecall?" // 1000 per day - check every 10 minutes
var forecast35URL = "http://api.openweathermap.org/data/2.5/forecast?" // Every 3 hours 5 day forcaset, lat,lon,units, cod 200 on success
var curWeathURL = "http://api.openweathermap.org/data/2.5/weather?" // lat,lon,units, cod 200 on success
var geoSearchZipCodeURL = "http://api.openweathermap.org/geo/1.0/zip?" // zip and country code
var geoSearchNameURL = "http://api.openweathermap.org/geo/1.0/direct?" // City Name, state*, country code. *not actually using state

// Help Prevent from calling the onecall API too often
// An array of locations
/*
var onecallCache = [
    {
        updated : null,
        lat : null,
        lon : null,
        cache : {}
    }
]
*/

/**
 * 
 * @returns The current UTC midnight
 */
function getUsageDate() {
    // The day this api is running
    let usageDate = new Date();
    // open weather API uses UTC time for tracking usage
    usageDate.setUTCHours(0,0,0,0)
    return usageDate;
}

function loadAPIUsage() {
    return fsio.readFile("Project/data/logs/" + getUsageDate().getTime() + ".json").then((content) => {
        // process log content
        let log = JSON.parse(content);
        let log_time = new Date(log.timestamp);
        if (Date.now() - log_time.getTime() < 1000*60) {
            // If the difference between the current time and the timestamp is less than one minute (60000ms), 
            // load the minute usage as well
            api_usage.onecall_minute = log.data.onecall_minute;
            api_usage.reg_minute = log.data.reg_minute;
        }
        api_usage.onecall_daily = log.data.onecall_daily;
        api_usage.reg_daily = log.data.reg_daily;
        return;

    }, (err) => {
        if (err.code == 'ENOENT') {
            // no file found, create the file
            logAPIUsage();
        }
    })
}

function displayAPIUsage() {
    console.log("> API USAGE: " + Date.now() + " FOR: " + getUsageDate().getTime())
    console.log("> OneCall: Minute[" + api_usage.onecall_minute + "] Daily[" + api_usage.onecall_daily + "]")
    console.log("> Regular: Minute[" + api_usage.reg_minute + "] Daily[" + api_usage.reg_daily + "]")
    console.log("\n")

    // It has been a minute, reset the cpm numbers
    api_usage.onecall_minute = 0;
    api_usage.reg_minute = 0;

    setTimeout(displayAPIUsage, 60000) // Run once a minute is 60000
}


function logAPIUsage() {
    logFile(getUsageDate().getTime(), api_usage);
}

// write any log file to logs folder
function logFile(filename, filedata) {
    var log = {
        timestamp : Date.now(),
        data : filedata
    }

    fsio.writeFile(log_root + filename + ".json", JSON.stringify(log));
}

/**
 * 
 * @param {*} zip A zipcode for a US location
 * @returns The lat and lon for the provided zipcode
 */
function lookupByZip(data) {
    return new Promise((resolve, reject) => {

        // Dynamically create the parameters
        let params = new URLSearchParams({
            "appid" : API_ID,
            "zip" : data.zip + ((data.country == null) ? "" : ("," + data.country))
        });
        let url = geoSearchZipCodeURL + params.toString();

        // pass along res/rej functions
        queryOpenWeatherMap(url).then(resolve, reject)

    })
}

/**
 * 
 * @param {*} name The Name of a City
 * @returns An array of cities that match the given name
 */
function lookupByName(data) {
    return new Promise((resolve, reject) => {

        // Dynamically create the URL parameters
        let params = new URLSearchParams({
            "appid" : API_ID,
            "q" : [data.name,(data.country == null) ? "" : data.country],
            "limit" : ((data.limit == null) ? "10" : data.limit)
        });
        let url = geoSearchNameURL + params.toString();

        queryOpenWeatherMap(url).then(resolve, reject)
    })
}


/**
 * Uses the OneCall API
 * 
 * @param {*} data The raw location data requested by the user
 * @returns 
 */
function getForecast(data) {
    return new Promise((resolve, reject) => {
        let params = new URLSearchParams({
            "appid" : API_ID,
            "lat" : data.lat,
            "lon" : data.lon,
            "units" : "imperial",
            "exclude" : ["alerts", "minutely" ,"daily"]
        });
        let url = oneCallURL + params.toString();

        queryOpenWeatherMap(url, true).then(resolve, reject)
    })
}


function getCurWeather(data) {
    return new Promise((resolve, reject) => {
        let params = new URLSearchParams({
            "appid" : API_ID,
            "lat" : data.lat,
            "lon" : data.lon,
            "units" : "imperial",
        });
        let url = curWeathURL + params.toString();

        queryOpenWeatherMap(url).then(resolve, reject)
    })
}

function get35Forecast(data) {
    return new Promise((resolve, reject) => {
        let params = new URLSearchParams({
            "appid" : API_ID,
            "lat" : data.lat,
            "lon" : data.lon,
            "units" : "imperial",
        });
        let url = forecast35URL + params.toString();

        queryOpenWeatherMap(url).then(resolve, reject)
    })
}

/** TODO, before making the API call, check if the call will violate the CPM for Regular or OneCall
 * If CPM violation, just wait until the next minute,
 * If Daily violation, reject or pull from cache
 * 
 * @param {*} url The URL for querying OpenWeatherMap
 * @returns An error or the response data
 */
function queryOpenWeatherMap(url, onecall=false) {

    let violationType = null;

    let errMsg = "API Daily Violation: ";

    // Determine type of violation (onecall or regular, daily or minute)
    if (onecall) {
        // if there is an incomming onecall request

        if (api_usage.onecall_daily >= API_LIMITS.onecall_daily) {
            api_violations.onecall_daily = true;

            // daily violation detected, reject request
            errMsg += "OneCall"
            return new Promise((resolve, reject) => {
                reject(new Error(errMsg))
            })
        }
        if (api_usage.onecall_minute >= API_LIMITS.onecall_minute) {
            api_violations.onecall_minute = true;
        }
    } else {
        // incomming regular request

        if (api_usage.reg_daily >= API_LIMITS.reg_daily) {
            api_violations.reg_daily = true;

            // daily violation detected, reject request
            errMsg += "Regular"
            return new Promise((resolve, reject) => {
                reject(new Error(errMsg))
            })
        }
        if (api_usage.reg_minute >= API_LIMITS.reg_minute) {
            api_violations.reg_minute = true;
        }
    }


    if ((onecall && api_violations.onecall_minute) || (!onecall && api_violations.reg_minute)) {
        // we have a onecall request and onecall in minute violation - delay
        // OR
        // we have a regular request and a regular violation
        // THERFORE
        // delay the request one minute

        return new Promise((resolve, reject) => {
            setTimeout(function() {
                // reset the minute violation status
                if (onecall) {
                    api_violations.onecall_minute = false;
                } else {
                    api_violations.reg_minute = false;
                }
                resolve(queryOpenWeatherMap(url, onecall))
            }, 60000)
        })


    } else {
        // there should be no violations at this point
        // API request will be processed by external API

    /* Testing Purposes
        // here to protect actual API usage during testing
        return new Promise((resolve, reject) => {
            // track API usage
            if (onecall) {
                api_usage.onecall_minute += 1;
                api_usage.onecall_daily += 1;
            } else {
                api_usage.reg_minute += 1;
                api_usage.reg_daily += 1;
            }
            logAPIUsage();
            resolve("Query good to run")
        })
    */
    
        return new Promise((resolve, reject) => {
            http.get(url, (res) => {

                // track API usage
                if (onecall) {
                    api_usage.onecall_minute += 1;
                    api_usage.onecall_daily += 1;
                } else {
                    api_usage.reg_minute += 1;
                    api_usage.reg_daily += 1;
                }
                logAPIUsage();


                let data = "";
                // call as data is coming in
                res.on("data", (chunk) => {
                    data += chunk;
                });

                // called when all data is received
                res.on("end", () => {
                    let result = JSON.parse(data);

                    // An API response but invalid data
                    // cod 200 is valid data
                    if (result.cod != null && result.cod != 200) {
                        reject("Weather API Error: " + result.message);
                    }

                    resolve(result);
                });

            }).on("error", (error) => {
                reject(error);
            });
        })
    }
}


/**
 * 
 * @param {*} func The API function to call
 * @param {*} req The data passed into the function. Can be primitive or an object, whichever the function expects. 
 * @returns An error or a response from OpenWeatherMap
 */
exports.processRequest = function(func, parameter) {
    return new Promise((resolve, reject) => {
        // All weatherAPI functions return a promise
        funcMap[func](parameter).then((response) => {
            resolve(response)
        }, (err) => {
            reject(err);
        })
    })
}


exports.setLogRoot = function(root) {
    log_root = root;
    // run at startup
    loadAPIUsage().then(() => {
        displayAPIUsage()
    });
}
/* Saving a file
var filename = "Project/data/" + getUsageDate().getTime() + ".json"
fsio.writeFile(filename, JSON.stringify(api_usage));
*/