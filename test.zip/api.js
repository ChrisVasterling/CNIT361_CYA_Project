var weatherAPI = require("./apiWeather")    // access funcs to the weather API
var databaseAPI = require("./apiDatabase")  // access funcs to the database API

exports.setConfigs = function(c) {
    weatherAPI.setLogRoot(c.log_root);
    databaseAPI.setDBConfig({
        "db_config" : c.db_config,
        "data_root" : c.data_root,
    })
}

/**
 * Receive JSON request and return JSON response. Response may be valid data or error.
 * 
 * @param {*} req An API request in json format
 * @returns The result of the request in JSON format
 */
exports.processRequest = function(req) {
    return new Promise((resolve, reject) => {
        // process the request

        switch(req.api) {
            case "general":
                // TODO?
                // preferences, etc;
                break;
            case "weather":
                // Process the API request with the weather functions
                weatherAPI.processRequest(req.function, req.data).then((response) => {
                    resolve(response);
                }).catch((err) => {
                    reject(err)
                });
                break;
            case "database":
                // Pass the request to the functions that handle communicating with the database
                databaseAPI.processRequest(req.function, req.data).then((response) => {
                    resolve(response);
                }).catch((err) => {
                    reject(err)
                });
                break;
        }
        // throw new Error("") - for any errors
    })
}