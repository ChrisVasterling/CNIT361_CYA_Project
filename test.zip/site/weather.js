function locationSearch() {
    let zipcode = document.getElementById("zipcode");
    let city = document.getElementById("city");
    let cityName = city.value
    let options = {};
    if (zipcode.value != "") {
        options = {
            api : "weather",
            function : "lookupByZip",
            data : {
                zip : zipcode.value,
            }
        }
    } else if (city.value != "") {
        options = {
            api : "weather",
            function : "lookupByName",
            data : {
                name : cityName,
            }
        }
    }

    API(options).then((result) => {
        var weatherSearch = document.getElementById("weatherSearch");
        weatherSearch.innerHTML = "";
        zipcode.value = "";
        city.value = "";
        if (!result.error) {
            console.log(result)
            if (!Array.isArray(result)) {
                // convert to array
                let temp = result;
                result = [temp];
            }
            if(result.length == 0) {
                let message = "The location:<br>\"";
                message += cityName
                message += "\"<br>Could not be found. Please try again."
                weatherSearch.innerHTML = message;
            }
            
            result.forEach((location) => {
                var loc = document.createElement("p");
                var GWBtn = document.createElement("button");
                var locInfo = document.createElement("span")
                GWBtn.setAttribute("onclick", "getLocCurWeather(this.id)");
                GWBtn.setAttribute("data-loc_info", JSON.stringify(location))
                GWBtn.setAttribute("id", "loc-" + location.lat + "," + location.lon);
                GWBtn.innerText = "Get Weather";
                locInfo.innerHTML = location.name + "," + ((location.state != null) ? location.state + ",": "") + location.country
                loc.appendChild(GWBtn)
                loc.appendChild(locInfo)
                weatherSearch.appendChild(loc);
            })

        } else {
            let message = "The following error was encountered:<br>";
            message += result.message
            message += "<br>Please try again."
            weatherSearch.innerHTML = message;
        }
    })
}

function getLocCurWeather(id) {
    var location = JSON.parse(document.getElementById(id).dataset.loc_info);
    
    let request = {
        api : "weather", 
        function : "getCurWeather", 
        data : {
            lat : location.lat, 
            lon : location.lon
        }
    }

    
    API(request).then((result) => {
        // clear the search area
        var weatherSearch = document.getElementById("weatherSearch");
        //weatherSearch.innerHTML = "";
        if (!result.error) {
            var weatherRoot = document.getElementById("weatherRoot");
            weatherRoot.innerHTML = "";
            var title = document.createElement("h3");
            title.innerHTML = "Weather for " + location.name + "," + ((location.state != null) ? location.state + ",": "") + location.country
            weatherRoot.appendChild(title);

            console.log(result);

            let dataPoints = [
                {name : "Time", data : (new Date(result.dt*1000)).toLocaleString()},
                {name : "Current Temperature", data : result.main.temp + "F"},
                {name : "Feels Like", data : result.main.feels_like + "F"},
                {name : "Humidity", data : result.main.humidity + "%"},
                {name : "Wind Speed", data : result.wind.speed + "mph"},
                {name : "Description", data : result.weather[0].description},
                {name : "icon", data : `<img src="http://openweathermap.org/img/wn/` + result.weather[0].icon + `.png"/>`}
            ]
            var data_table = document.createElement("table");

            dataPoints.forEach((point) => {
                var row = document.createElement("tr")
                var name = document.createElement("td");
                var value = document.createElement("td");
                name.setAttribute("style", "text-align:right");
                value.setAttribute("style", "text-align:left")
                name.innerHTML = point.name + ":"
                value.innerHTML = point.data
                row.appendChild(name);
                row.appendChild(value);
                data_table.appendChild(row);
            })

            weatherRoot.appendChild(data_table)
        }
    })

}

function getLocForecast(type="onecall") {
    // 3x5 or onecall type
}


function collapseLocationResults() {
    // hide all search results
    // change onlcick function to expandLocationResults
}

function expandLocationResults() {
    // display all search results
    // change onlcick function to collapseLocationResults
}

function displayLocationResults(locations) {
    // display the list of locations
}

function displayCurWeather(data) {
    // display the current weather for a location
}

function displayForecast(data) {
    // TODO? Display the forecast for a location
}