function displayNote(name, id) {
    let list = document.getElementById("noteList");
    let noteName = document.createElement("div");
    noteName.innerHTML = name;
    noteName.setAttribute("id", "note-" + id);
    noteName.setAttribute("data-note", id);
    noteName.setAttribute("class", "note");
    noteName.setAttribute("onclick", "openNote(this.id)")

    list.appendChild(noteName);
}

function setNoteControls(id="") {
    let saveBtn = document.getElementById("note-save");
    let deleteBtn = document.getElementById("note-delete");

    saveBtn.dataset.note = id;
    deleteBtn.dataset.note = id;
}

function checkNoteChanges(location) {
    let icon = document.getElementById("note-need-save");
    let content = document.getElementById("note-content");
    let nameBox = document.getElementById("note-box-name");

    if (location == "func_update") {
        icon.style.visibility = "hidden";
        return;
    }
    if (location == "name") {
        if (nameBox.value == noteNameSinceSave) {
            icon.style.visibility = "hidden";
        } else {
            icon.style.visibility = "visible";
        }
    }

    if (location == "content") {
        if (content.value == noteContentSinceSave) {
            icon.style.visibility = "hidden";
        } else {
            icon.style.visibility = "visible";
        }
    }
}

var noteContentSinceSave = "";
var noteNameSinceSave = "";
function openNote(eleID, newNote=false) {
    let id = document.getElementById(eleID).dataset.note;
    let noteName = document.getElementById(eleID).innerHTML;
    let noteTextBox = document.getElementById("note-box-name");
    let noteContent = document.getElementById("note-content");
    let noteControls = document.getElementById("note-controls");


    let options = {
        api : "database",
        function : "getNote",
        data : {
            noteID : id
        } 
    }
    API(options).then((response) => {

        if (response.error) {
            alert("Error getting note content")
        } else {
            noteTextBox.value = noteName;
            noteContent.value = response;
            noteNameSinceSave = noteName;
            noteContentSinceSave = response;
            noteControls.style.display = "";
            noteContent.style.visibility = "visible";
            if (newNote) {
                noteTextBox.select();
                noteTextBox.focus();
            } else {
                noteContent.focus();
            }
            setNoteControls(id);
        }

    })
}

function removeNoteVisual(noteID) {
    let note = document.getElementById("note-" + noteID);
    let noteTextBox = document.getElementById("note-box-name");
    let noteContent = document.getElementById("note-content");
    let noteControls = document.getElementById("note-controls");

    note.parentNode.removeChild(note);
    noteTextBox.value = "";
    noteContent.value = "";

    noteControls.style.display = "none";
    noteContent.style.visibility = "hidden";

}

function addNote() {
    let noteName = "Untitled";
    let noteContent = "";
    let options = {
        api : "database",
        function : "addNote",
        data : {
            name : noteName,
            content : noteContent
        }
    }
    API(options).then((result) => {
        console.log(result);
        displayNote(noteName, result.insertId)
        openNote("note-" + result.insertId, true)
    })
}

function updateNote(eleID) {
    let id = document.getElementById(eleID).dataset.note;
    let noteLabel = document.getElementById("note-" + id)
    let noteName = document.getElementById("note-box-name");
    let noteContent = document.getElementById("note-content");
    let icon = document.getElementById("note-need-save");
    let options = {
        api : "database",
        function : "updateNote",
        data : {
            noteID : id,
            name : noteName.value,
            content : noteContent.value
        } 
    }
    API(options).then((response) => {
        console.log(response)
        noteNameSinceSave = noteName.value;
        noteContentSinceSave = noteContent.value;
        noteLabel.innerHTML = noteName.value;
        checkNoteChanges("func_update")
    })
}

function deleteNote(eleID) {
    let id = document.getElementById(eleID).dataset.note;
    if (id == "") {
        return;
    }
    let options = {
        api : "database",
        function : "removeNote",
        data : {
            noteID : id
        } 
    }
    API(options).then((response) => {
        console.log(response)
        removeNoteVisual(id);
        setNoteControls();
    })
}