/**
 * 
 * 
 */
var mysql = require('mysql');               // access mysql database
var fsio = require("./fsio");               // access file system

// Functions accessible by client
var funcMap = {
    "getInitialInfo" : getInitialInfo,
    "addTask" : addTask,
    "addNote" : addNote,
    "getNote" : getNote,
    "removeNote" : removeNote,
    "updateNote" : updateNote,
    "removeTask" : removeTask,
    "updateTask" : updateTask
}


var db_status = {
    online : false,
}

// The connnection info for connection to the (local) database
var DBConfig = {};
var data_root;
var MYSQLCon;

function handleDBDisconnect() {
    MYSQLCon = mysql.createConnection(DBConfig);

    MYSQLCon.connect((err) => {
        if (err) {
            console.log("Error connecting to DB: ", err)
            console.log("Trying again in 5 seconds...")
            setTimeout(handleDBDisconnect, 5000)
        } else {
            console.log("Successfully connected to DB")
            db_status.online = true;
        }
    })

    MYSQLCon.on("error", (err) => {
        console.log("DB Error: ", err)
        db_status.online = false;
        if(err.code === 'PROTOCOL_CONNECTION_LOST') { 
            handleDBDisconnect();  
        } else {
            throw err;
        }
    })
}

/**
 * 
 * @param {*} query The SQL quet in a perpared Statement Format
 * @param {*} queryData The data to be plased in to the query
 * @returns A table as an array of rows
 */
function queryDatabase(query, queryData=[]) {
    return new Promise((resolve, reject) => {
        MYSQLCon.query(query, queryData, function(err, result) {
            if (err) {
                reject(err)
            }
            resolve(result);
        });
    })
}

function getNotes() {
    let query = `SELECT * FROM note`;
    return queryDatabase(query)
}

function getMaxID(table) {
    let query = `SELECT MAX(ID) AS MAX_ID FROM ??`;
    return queryDatabase(query, [table])
}

function getTasks(status) {
    let query = `SELECT * FROM task WHERE complete = ?`;
    return queryDatabase(query, [status])
}

/**
 * Get the initial infor required to display the webpage.
 * @returns All notes, tasks, the max note ID, the max task ID
 */
function getInitialInfo() {
    return new Promise((resolve, reject) => {

        // All must succeed to be valid 
        Promise.allSettled([
            getNotes(),
            getMaxID("note"),
            getTasks(0),
            getMaxID("task")
        ]).then((data) => {
            // restructure response (easier to read/work with raw JSON)
            let DBRes = {
                notes : (data[0].status == "fulfilled" ? data[0].value : data[0]),
                maxNoteID : (data[1].status == "fulfilled" ? data[1].value[0]["MAX_ID"] : data[1]),
                tasks : (data[2].status == "fulfilled" ? data[2].value : data[2]),
                maxTaskID : (data[3].status == "fulfilled" ? data[3].value[0]["MAX_ID"] : data[3]),
            };

            if (DBRes.maxNoteID != null && DBRes.maxNoteID.status == "rejected" ||
            DBRes.maxTaskID != null && DBRes.maxTaskID.status == "rejected") {
                // Reject if we can't determine the max id for a table
                reject(new Error("Could not determine max ID for notes or task"))
            } else {
               resolve(DBRes);
            }

        })

    })
}

function addTask(data) {
    let query = `INSERT INTO task (name, complete) VALUE (?, 0)`
    return queryDatabase(query, [data.name])
}

function addNote(data) {
    let query = `INSERT INTO note (name) VALUE (?)`
    // also handle saving data.content
    return new Promise((resolve, reject) => {
        queryDatabase(query, [data.name]).then((response) => {
            fsio.writeFile(data_root + "note-" + response.insertId + ".txt", data.content)
            resolve(response)
        })
    })
}

function getNote(data) {
    return new Promise((resolve, reject) => {
        fsio.readFile(data_root + "note-" + data.noteID + ".txt", "utf-8").then((fileContent) => {
            resolve(fileContent);
        }, (err) => {
            reject(new Error("Could not find note for: " + data.noteID))
        })
    })
}

function removeTask(data) {
    let query = `DELETE FROM task WHERE ID = ?`;
    return queryDatabase(query, [data.taskID])
}

function removeNote(data) {
    let query = `DELETE FROM note WHERE ID = ?`

    return new Promise((resolve, reject) => {
        queryDatabase(query, [data.noteID]).then((response) => {
            fsio.removeFile(data_root + "note-" + data.noteID + ".txt").catch((err) => {console.log(err)});
            resolve(response);
        })
    })
}

function updateTask(data) {
    let query = `UPDATE task SET name = ?, complete = ? WHERE ID = ?`;
    return queryDatabase(query, [data.name, data.complete, data.taskID])
}

function updateNote(data) {
    let query = `UPDATE note SET name = ? WHERE ID = ?`;
    return new Promise((resolve, reject) => {
        queryDatabase(query, [data.name, data.noteID]).then((response) => {
            fsio.writeFile(data_root + "note-" + data.noteID + ".txt", data.content)
            resolve(response)
        })
    })
}



exports.processRequest = function(func, parameter) {
    return new Promise((resolve, reject) => {
        if (!db_status.online) {
            reject(new Error("Database Offline"))
        }
        // All databseAPI functions return a promise
        funcMap[func](parameter).then((response) => {
            resolve(response)
        }, (err) => {
            reject(err);
        })
    })
}

exports.setDBConfig = function(config) {
    data_root = config.data_root
    DBConfig = config.db_config
    handleDBDisconnect();
}