var fs = require('fs')  // Access the file system


/**
* 
* @returns A promise that resolves with file data or an error message
*/
exports.readFile = function(filename, encoding=null) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, encoding, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        })
    })
}

exports.writeFile = function(filename, content) {
    return new Promise((resolve, reject) => {
        fs.writeFile(filename, content, (err) => {
            if (err) {
                reject(err.message);
            } else {
                resolve();
            }
        })
    })
}


exports.removeFile = function(filename) {
    return new Promise((resolve, reject) => {
        fs.unlink(filename, (err) => {
            if (err) {
                reject(err.message);
            } else {
                resolve();
            }
        })
    })
}



