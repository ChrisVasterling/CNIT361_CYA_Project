var http = require('http');                 // create http server
var childProc = require('child_process');   // access cmd commands
var fsio = require("./fsio");               // access files
var api = require("./api")                  // handle all api requests

// all html, css, js files served to the user are in the /site directory
// Project/site because of a quirk in how VSCode handles working directories
// When running "oficially", use only "site" and run from the folder directly - no the parent folder like in VSCode
var webpage_root;// = "Project/site"; 

/**
 * The HTTP Server is the heart of the flow of information
 */
var server = http.createServer(function(req, res) {

    var baseURL = "http://" + req.headers.host;
    var URLdata = new URL(req.url, baseURL);
    var URLsplit = URLdata.pathname.split('/');

    // Call the API from any page or subpage in /site/
    if (URLsplit[URLsplit.length - 1] == "api" && req.method == "POST") {

        // only accept POST requests for API calls
        // this is because most requests will probably have attached "body" data

        // Receive stringified JSON api request
        var data = '';
        req.on('data', (chunk) => {
            data += chunk;
        })

        // runs when all data is received (i.e. process the request)
        req.on('end', () => {

            // convert POST body data to JSON
            apiReq = JSON.parse(data);

            // Process the API Request
            api.processRequest(apiReq).then((apiRes) => {
                // request has been processed, return it to the user

                // Return stringified JSON api response
                res.write(JSON.stringify(apiRes));
                res.end();

            }).catch((err) => {
                // any and all API errors should come back to here to be handled

                console.log("API ERROR! - " + err)

                let apiRes = {
                    error : true,
                    message : err.toString()     
                }
                res.write(JSON.stringify(apiRes));
                res.end();
            });
            
        })

    } else {

        // Handles determining and delivering site assets on a request 
        // (html, css, js, images, etc.)


        // reditect user to site/index.html if accessing root location 
        // and pass along any url parameters
        if (URLdata.pathname == "/") {
            res.statusCode = 302;
            res.setHeader('Location', '/index.html' + URLdata.search);
            res.end();
            return;
        }

        // site/folder/file.ext
        // "site/test/file%20spaces.ext" => "site/test/file spaces.ext"
        var filename = webpage_root + decodeURIComponent(URLdata.pathname);
        
        // File extension used to potentially get content type
        //var fileExt = filename.substring(filename.lastIndexOf('.')+1, filename.length);
        //res.writeHead(200, {'Content-Type':'text/html'})

        // Attempt to load the requested file
        // By using "filename", requests will only have access to the entire /site directory
        fsio.readFile(filename).then((fileData) => {
            res.write(fileData);
            res.end();
        }, (err) => {
            // There was an issue reading/opening the file. 
            // In many cases, it's probably because the file doesn't exist.
            // Throw a 404 to the user and provide link to homepage

            res.writeHead(200, {'Content-Type':'text/html'})
            res.write("404 File Not Found.")
            res.write(
                `<br><a href="/index.html">Return Home</a>`);
            res.end();
            
            // hide the error message for missing favicon.ico - it appears a lot
            if (!filename.endsWith("favicon.ico")) {
                console.log("ERROR Loading File: " + err.message);
            }
        })
    }
})

/**
 * Load the config file and send configurations to
 * api config function. This func handles things such as
 * Connecting to the database and generating log files
 * 
 */
var appRoot = "Project/";
fsio.readFile(appRoot + "conf.json", "utf-8").then((data) => {
    let config = JSON.parse(data);
    webpage_root = config.webpage_root;
    api.setConfigs(config)
}).then(()=>{
    server.listen(8080)
})

// Static Port
//server.listen(8080);
/* Dynamic Port
server.listen();
console.log("Listening on: http://localhost:" + server.address().port);
*/


// Automatically open homepage in default browser
//childProc.exec("start " + "http://localhost:" + server.address().port)

/* Another way of auto-opening (back-ticks are important)
const localURL = "http://localhost"
childProc.exec("start " + `${localURL}:` + server.address().port)
*/