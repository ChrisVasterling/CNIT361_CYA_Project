CREATE TABLE `note` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
);
CREATE TABLE `task` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `complete` tinyint DEFAULT '0',
  PRIMARY KEY (`ID`)
) 