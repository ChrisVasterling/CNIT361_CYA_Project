var fs = require('fs')  // Access the file system

var root = __dirname + "/"

/**
* 
* @returns A promise that resolves with file data or an error message
*/
exports.readFile = function(filename, encoding=null) {
    return new Promise((resolve, reject) => {
        fs.readFile(root + filename, encoding, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        })
    })
}

exports.writeFile = function(filename, content) {
    return new Promise((resolve, reject) => {
        fs.writeFile(root + filename, content, (err) => {
            if (err) {
                reject(err.message);
            } else {
                resolve();
            }
        })
    })
}


exports.removeFile = function(filename) {
    return new Promise((resolve, reject) => {
        fs.unlink(root + filename, (err) => {
            if (err) {
                reject(err.message);
            } else {
                resolve();
            }
        })
    })
}



