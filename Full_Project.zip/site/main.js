window.addEventListener("load", () => {
    var options = {
        method : "POST",
        body : JSON.stringify({
            api : "database",
            function : "getInitialInfo",
            data : {}
        })}
    fetch("api", options).then((response) => {
        return response.json()
    }).then((result) => {

        // display the current tasks
        if (result.tasks.status != "rejected") {
            result.tasks.forEach((task) => {
                displayTask(task.name, task.ID)
            })
        }

        // display the current notes
        if (result.notes.status != "rejected") {
            result.notes.forEach((note) => {
                displayNote(note.name, note.ID)
            })
        }

    })
})


function API(request) {
    return new Promise((resolve, reject) => {
        var options = {
            method : "POST",
            body : JSON.stringify(request)}
        fetch("api", options).then((response) => {
            return response.json()
        }).then((result) => {
            resolve(result);
        })
    })
}

