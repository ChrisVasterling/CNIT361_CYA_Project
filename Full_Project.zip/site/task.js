function displayTask(name, id) {
    let list = document.getElementById("taskList");
    let task = document.createElement("div");
    let viewTask = document.createElement("div");
    let editTask = document.createElement("div");
    let editBtn = document.createElement("button");
    let saveBtn = document.createElement("button");
    let cancelBtn = document.createElement("button");
    let deleteBtn = document.createElement("button");
    let checkBox = document.createElement("input");
    let taskLabel = document.createElement("label");
    let textBox = document.createElement("input");

    task.setAttribute("id", "task-" + id);
    task.setAttribute("class", "task");

    viewTask.setAttribute("id", "task-view-" + id);
    viewTask.setAttribute("class", "viewTask");

    checkBox.setAttribute("id", "task-check-" + id);
    checkBox.setAttribute("class", "taskCheck");
    checkBox.setAttribute("type", "checkbox");
    checkBox.setAttribute("data-task", id)
    checkBox.setAttribute("onchange", "handleTaskStatusChange(this.id)")

    taskLabel.setAttribute("id", "task-label-" + id);
    taskLabel.setAttribute("class", "taskLbl")
    taskLabel.setAttribute("for", "task-check-" + id);
    taskLabel.innerHTML = name;

    editBtn.innerHTML = "<i class='fa fa-edit'></i>";
    editBtn.setAttribute("data-task", id)
    editBtn.setAttribute("id", "task-btn-edit-" + id)
    editBtn.setAttribute("onclick", "editTask(this.id)")


    editTask.setAttribute("id", "task-edit-" + id);
    editTask.setAttribute("class", "editTask");

    deleteBtn.innerHTML = "<i class='fa fa-trash'></i>";
    deleteBtn.setAttribute("data-task", id)
    deleteBtn.setAttribute("id", "task-btn-delete-" + id)
    deleteBtn.setAttribute("onclick", "deleteTask(this.id)")

    textBox.setAttribute("id", "task-text-box-" + id)
    textBox.setAttribute("type", "text");

    saveBtn.innerHTML = "<i class='	fa fa-floppy-o'></i>";
    saveBtn.setAttribute("data-task", id)
    saveBtn.setAttribute("id", "task-btn-save-" + id)
    saveBtn.setAttribute("onclick", "updateTask(this.id)")

    cancelBtn.innerHTML = "&#10006;";
    cancelBtn.setAttribute("data-task", id)
    cancelBtn.setAttribute("id", "task-btn-cancel-" + id)
    cancelBtn.setAttribute("onclick", "cancelTaskEdit(this.id)")

    viewTask.appendChild(checkBox);
    viewTask.appendChild(taskLabel);
    viewTask.appendChild(editBtn);

    editTask.appendChild(deleteBtn);
    editTask.appendChild(textBox);
    editTask.appendChild(saveBtn);
    editTask.appendChild(cancelBtn);

    task.appendChild(viewTask);
    task.appendChild(editTask);
    list.appendChild(task);
}

function removeTaskVisual(taskID) {
    let task = document.getElementById("task-" + taskID);
    task.parentNode.removeChild(task);
}

function addTask() {
    let taskName = document.getElementById("taskName");

    if (taskName.value == "") {
        alert("Please enter a task name.") 
        return;
    }

    let request = {
        api : "database",
        function : "addTask",
        data : {
            name : taskName.value
        }
    }

    API(request).then((result) => {
        console.log(result);
        displayTask(taskName.value, result.insertId)
        taskName.value = "";
        taskName.focus()
    })
}

function editTask(eleID) {
    let taskID = document.getElementById(eleID).dataset.task;
    let view = document.getElementById("task-view-" + taskID);
    let taskLabel = document.getElementById("task-label-" + taskID);
    let edit = document.getElementById("task-edit-" + taskID);
    let editBox = document.getElementById("task-text-box-" + taskID);

    editBox.value = taskLabel.innerHTML;
    view.style.display = "none";
    edit.style.display = "inherit";
}

function cancelTaskEdit(eleID) {
    // ignore changes, switch back to old mode
    let taskID = document.getElementById(eleID).dataset.task;
    let view = document.getElementById("task-view-" + taskID);
    let taskLabel = document.getElementById("task-label-" + taskID);
    let edit = document.getElementById("task-edit-" + taskID);
    let editBox = document.getElementById("task-text-box-" + taskID);

    if (editBox.value != taskLabel.innerHTML) {
        if (!confirm("Changes Detected. Are you sure you want to cancel?")) {
            return;
        }
    }
    
    view.style.display = "inherit";
    edit.style.display = "none";
}

function updateTask(eleID) {
    // update UI and send changes to server
    let id = document.getElementById(eleID).dataset.task;
    let taskLabel = document.getElementById("task-label-" + id);
    let editBox = document.getElementById("task-text-box-" + id);

    if (editBox.value == "") {
        alert("Please enter a task name.") 
        return;
    }
    if (taskLabel.innerHTML == editBox.value) {
        cancelTaskEdit(eleID)
        return;
    }

    let options = {
        api : "database",
        function : "updateTask",
        data : {
            taskID : id,
            complete : 0,
            name : editBox.value,
        } 
    }

    API(options).then((response) => {
        console.log(response)
        taskLabel.innerHTML = editBox.value;
        cancelTaskEdit(eleID)
    })
}

function deleteTask(eleID) {
    let id = document.getElementById(eleID).dataset.task;
    let options = {
        api : "database",
        function : "removeTask",
        data : {
            taskID : id
        } 
    }

    API(options).then((response) => {
        console.log(response)
        removeTaskVisual(id)
    })
}

function handleTaskStatusChange(eleID) {
    let id = document.getElementById(eleID).dataset.task;
    let checkBox = document.getElementById(eleID);
    checkBox.disabled = true;

    let options = {
        api : "database",
        function : "updateTask",
        data : {
            taskID : id,
            complete : 1,
            name : document.getElementById("task-label-" + id).innerHTML
        } 
    }
    API(options).then((response) => {
        console.log(response)
        setTimeout(() => {
            removeTaskVisual(id);
        }, 150)
    })

}