var cur_loc = {};

function locationSearch() {
    let zipcode = document.getElementById("search-zip");
    let city = document.getElementById("search-city");
    let searchValue = ""
    let options = {};

    // if both boxes have data, prioritize zipcode
    if (zipcode.value != "" && city.value != "") {
        let message = "Zipcode and City detected. \n Searching by Zipcode";
        if (!confirm(message)) {
            return;
        }
    }

    if (zipcode.value != "") {
        searchValue = zipcode.value;
        options = {
            api : "weather",
            function : "lookupByZip",
            data : {
                zip : zipcode.value,
            }
        }
    } else if (city.value != "") {
        searchValue = city.value;
        options = {
            api : "weather",
            function : "lookupByName",
            data : {
                name : city.value,
            }
        }
    }

    API(options).then((result) => {
        if (!result.error) {
            console.log(result)
            if (!Array.isArray(result)) {
                // convert to array
                let temp = result;
                result = [temp];
            }

            if(result.length == 0) {
                let message = "The location:\n\"";
                message += city.value
                message += "\"\nCould not be found. Please try again."
                alert(message)
                return;
            }
            
            zipcode.value = "";
            city.value = "";
            
            displayLocationResults(result, searchValue);
            return;

        } else {
            let message = "The following error was encountered:\n";
            message += result.message
            message += "\nPlease try again."
            alert(message)
            return;
        }
    })
}

function getLocCurWeather(id) {
    var location = JSON.parse(document.getElementById(id).dataset.loc_info);
    cur_loc = location;
    let request = {
        api : "weather", 
        function : "getCurWeather", 
        data : {
            lat : location.lat, 
            lon : location.lon
        }
    }
    collapseLocationResults();
    API(request).then((result) => {
        
        if (!result.error) {
            displayCurWeather(result, location)
            getLocForecast();
            return;
        } else {
            let message = "The following error was encountered:\n";
            message += result.message
            message += "\nPlease try again."
            alert(message)
            return;
        }
    })
}

function getLocForecast(onecall=false) {
    //var location = JSON.parse(document.getElementById(id).dataset.loc_info);

    let request = {
        api : "weather", 
        function : "get" + (onecall ? "" : "35") + "Forecast", 
        data : {
            lat : cur_loc.lat, 
            lon : cur_loc.lon
        }
    }
    API(request).then((result) => {
        
        if (!result.error) {
            // convert needed into into standard format
            let dataPoints = [];
            if (onecall) {
                result.hourly.forEach((hour) => {
                    dataPoints.push({
                        time : hour.dt,
                        temp : hour.temp,
                        feel : hour.feels_like,
                        humidity : hour.humidity,
                        wind_speed : hour.wind_speed,
                        desc : hour.weather[0].description,
                        icon : hour.weather[0].icon,
                    })
                });
            } else {
                result.list.forEach((instance) => {
                    dataPoints.push({
                        time : instance.dt,
                        temp : instance.main.temp,
                        feel : instance.main.feels_like,
                        humidity : instance.main.humidity,
                        wind_speed : instance.wind.speed,
                        desc : instance.weather[0].description,
                        icon : instance.weather[0].icon,
                    })
                })
            }

            displayForecast(dataPoints);
            return;

        } else {
            let message = "The following error was encountered:\n";
            message += result.message
            message += "\nPlease try again."
            alert(message)
            return;
        }
    })

    
}

function toggleResults() {
    let state = document.getElementById("colExpResults").dataset.state;
    if (state == "col") {
        expandLocationResults();
        return;
    }
    if (state == "exp") {
        collapseLocationResults();
        return;
    }

}

function collapseLocationResults() {
    let state = document.getElementById("colExpResults");
    let results = document.getElementById("weatherLocResults");
    state.innerHTML = "Expand"
    state.setAttribute("data-state", "col");
    results.style.display = "none";
}

function expandLocationResults() {
    let state = document.getElementById("colExpResults");
    let results = document.getElementById("weatherLocResults");
    state.innerHTML = "Collapse"
    state.setAttribute("data-state", "exp");
    results.style.display = null;
}

function displayLocationResults(locations, searchValue) {
    let rootDest = document.getElementById("weatherLocResults");
    let locDest = document.createElement("div");
    let label = document.createElement("div");
    let togBtn = document.getElementById("resultsToggleBtn")

    rootDest.innerHTML = "";
    locDest.setAttribute("class", "list")
    label.innerHTML = "Search Results for: " + searchValue

    locDest.appendChild(label);

    locations.forEach((location) => {
       let btn = document.createElement("button");
       // Eau Claire,WI,US
       btn.innerHTML = location.name + "," + ((location.state != null) ? location.state + ",": "") + location.country;
       btn.setAttribute("data-loc_info", JSON.stringify(location));
       btn.setAttribute("class", "weatherLoc");
       btn.setAttribute("id", "loc-" + location.lat + "," + location.log);
       btn.setAttribute("onclick", "getLocCurWeather(this.id)");
       locDest.appendChild(btn);
    })

    rootDest.appendChild(locDest)
    expandLocationResults();
    togBtn.style.display = null;
}

function displayCurWeather(weather_info, location_info) {
    document.getElementById("w-forecast-table").innerHTML = "";
    let dataPoints = [
        {dest_id : "w-loc", dest_type : "html", 
            value : (location_info.name + "," + ((location_info.state != null) ? location_info.state + ",": "") + location_info.country)},
        
        {dest_id : "w-time", dest_type : "html", 
            value : (new Date(weather_info.dt*1000)).toLocaleString()},
        
        {dest_id : "w-curtemp", dest_type : "html", 
            value : (weather_info.main.temp).toFixed(1) + "&#176;F"},
        
        {dest_id : "w-feeltemp", dest_type : "html", 
            value : (weather_info.main.feels_like).toFixed(1) + "&#176;F"},
        
        {dest_id : "w-humidity", dest_type : "html", 
            value : weather_info.main.humidity + "%"},
        
        {dest_id : "w-wind", dest_type : "html", 
            value : (weather_info.wind.speed).toFixed(1) + "mph"},
        
        {dest_id : "w-desc", dest_type : "html", 
            value : weather_info.weather[0].description},
        
        {dest_id : "w-icon", dest_type : "src", 
            value : "http://openweathermap.org/img/wn/" + weather_info.weather[0].icon + ".png"}
    ]

    dataPoints.forEach((data) => {
        if (data.dest_type == "html") {
            document.getElementById(data.dest_id).innerHTML = data.value
        } else {
            document.getElementById(data.dest_id).setAttribute(data.dest_type, data.value)
        }
    })

    document.getElementById("locWeather").style.display = null;

}

function displayForecast(data) {
    /* Experiment with graph
    let x_axis = [];
    let y_temp = [];
    let y_feel = [];
    data.forEach((point) => {
        x_axis.push(
            (new Date(point.time*1000).toDateString())
        );
        y_temp.push(point.temp);
        y_feel.push(point.feel);

    })
    new Chart("forecastChart", {
        type: "line",
        data: {
          labels: x_axis,
          datasets: [{ 
            data: y_temp,
            borderColor: "red",
            fill: false
          }, { 
            data: y_feel,
            borderColor: "green",
            fill: false
          }]
        },
        options: {
          legend: {display: true}
        }
      });
      */
    let dest = document.getElementById("w-forecast-table");
    let headerRow = document.createElement("tr");
    let headers = ["Time", "Icon", "Temp", "Humidity", "Wind", "Feels Like"]
    dest.innerHTML = "";

    headers.forEach((header) => {
        let th = document.createElement("th");
        th.innerHTML = header;
        headerRow.appendChild(th);
    })

    dest.append(headerRow);

    data.forEach((point) => {
        let tr = document.createElement("tr");
        let d = new Date(point.time * 1000);
        let options = {
            day : "numeric",
            month : "short",
            hour : "numeric",
            minute: "numeric",
        }
        let tds = [
            d.toLocaleString("en-us", options),
            `<img src="http://openweathermap.org/img/wn/` + point.icon + `.png"/>`,
            point.temp.toFixed(1) + "&#176;F",
            point.humidity + "%",
            point.wind_speed.toFixed(1) + "mph",
            point.feel.toFixed(1) + "&#176;F",
        ]
        tds.forEach((value) => {
            let td = document.createElement("td");
            td.innerHTML = value;
            tr.appendChild(td);
        })
        dest.appendChild(tr);
    })
}