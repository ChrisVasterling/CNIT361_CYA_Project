window.addEventListener("load", () => {
    var options = {
        method : "POST",
        body : JSON.stringify({
            api : "database",
            function : "getInitialInfo",
            data : {}
        })}
    fetch("api", options).then((response) => {
        return response.json()
    }).then((result) => {

        // display the current tasks
        if (result.tasks.status != "rejected") {
            result.tasks.forEach((task) => {
                displayTask(task.name, task.ID)
            })
        }

        // display the current notes
        if (result.notes.status != "rejected") {
            result.notes.forEach((note) => {
                displayNote(note.name, note.ID)
            })
        }

    })
})

function addTask() {
    var taskName = document.getElementById("taskName");
    var request = {
        api : "database",
        function : "addTask",
        data : {
            name : taskName.value
        }
    }
    API(request).then((result) => {
        console.log(result);
        displayTask(taskName.value, result.insertId)
    })
}

function addNote() {
    var noteName = document.getElementById("noteName");
    var noteContent = document.getElementById("noteContent")
    var request = {
        api : "database",
        function : "addNote",
        data : {
            name : noteName.value,
            content : noteContent.value
        }
    }
    API(request).then((result) => {
        console.log(result);

        displayNote(noteName.value, result.insertId)

    })
}

function displayTask(name, id) {
    var taskName = document.getElementById("taskName");
    let tr = document.getElementById("taskRoot")
    let nt = document.createElement("p");
    let cBox = document.createElement("input");
    let cBoxLbl = document.createElement("label");
    let delBtn = document.createElement("button");
    let svBtn = document.createElement("button");
    cBox.setAttribute("type", "checkbox");
    cBox.setAttribute("id", "check-" + id);
    cBox.setAttribute("data-taskid", id);
    cBoxLbl.innerHTML = name;
    cBoxLbl.setAttribute("id", "checklbl-" + id)
    delBtn.innerHTML = "Delete"
    svBtn.innerHTML = "Save"

    cBoxLbl.setAttribute("for", cBox.getAttribute("id"))
    nt.setAttribute("id", "task-root-" + id);
    delBtn.setAttribute("id", "deltask-" + id);
    svBtn.setAttribute("id", "svtask-" + id);

    delBtn.setAttribute("data-taskid", id)
    svBtn.setAttribute("data-taskid", id)

    cBox.setAttribute("onchange", "handleTaskChange(this.id)")
    delBtn.setAttribute("onclick", "deleteTask(this.id)")
    svBtn.setAttribute("onclick", "saveTask(this.id)")
    nt.appendChild(cBox);
    nt.appendChild(cBoxLbl);

    nt.appendChild(document.createElement("br"))

    nt.appendChild(delBtn);
    nt.appendChild(svBtn)
    tr.appendChild(nt);

    taskName.value = "";
}

function displayNote(name, id) {
    var noteName = document.getElementById("noteName");
    var noteContent = document.getElementById("noteContent")
    let nr = document.getElementById("noteRoot")
    let nn = document.createElement("p");
    let nna = document.createElement("span")
    let vnBtn = document.createElement("button");
    let delBtn = document.createElement("button");
    let svBtn = document.createElement("button");
    nn.setAttribute("id", "note-root-" + id)
    vnBtn.innerHTML = "View"
    delBtn.innerHTML = "Delete"
    svBtn.innerHTML = "Save"
    vnBtn.setAttribute("id", "note-" + id)
    delBtn.setAttribute("id", "delnote-" + id)
    svBtn.setAttribute("id", "savenote-" + id)
    nna.setAttribute("id", "namenote-" + id)
    vnBtn.setAttribute("data-noteid", id);
    delBtn.setAttribute("data-noteid", id)
    svBtn.setAttribute("data-noteid", id);
    vnBtn.setAttribute("onclick", "getNote(this.id)");
    delBtn.setAttribute("onclick", "deleteNote(this.id)")
    svBtn.setAttribute("onclick", "saveNote(this.id)")
    nna.innerHTML = name;
    nn.appendChild(nna);
    nn.appendChild(document.createElement("br"))
    nn.appendChild(vnBtn);
    nn.appendChild(delBtn)
    nn.appendChild(svBtn);
    nr.appendChild(nn);
    
    noteName.value = "";
    noteContent.value = "";
}

function getNote(eleID) {
    // get the content for a note
    // display in "note-root-ID" area
    var id = document.getElementById(eleID).dataset.noteid
    var name = document.getElementById("namenote-" + id).innerHTML;
    var noteName = document.getElementById("noteName");
    var noteContent = document.getElementById("noteContent")
    let options = {
        api : "database",
        function : "getNote",
        data : {
            noteID : id
        } 
    }
    API(options).then((response) => {

        if (response.error) {
            alert("Error getting note content")
        } else {
            noteName.value = name;
            noteContent.value = response;
        }

    })

}

function deleteTask(eleID) {
    var id = document.getElementById(eleID).dataset.taskid
    let options = {
        api : "database",
        function : "removeTask",
        data : {
            taskID : id
        } 
    }
    API(options).then((response) => {
        console.log(response)
        var note = document.getElementById("task-root-" + id);
        note.parentNode.removeChild(note);
    })
}

function deleteNote(eleID) {
    var id = document.getElementById(eleID).dataset.noteid
    let options = {
        api : "database",
        function : "removeNote",
        data : {
            noteID : id
        } 
    }
    API(options).then((response) => {
        console.log(response)
        var note = document.getElementById("note-root-" + id);
        note.parentNode.removeChild(note);
    })
}

function saveTask(eleID) {
    var taskName = document.getElementById("taskName");
    var id = document.getElementById(eleID).dataset.taskid
    let options = {
        api : "database",
        function : "updateTask",
        data : {
            taskID : id,
            complete : 0,
            name : taskName.value,
        } 
    }
    API(options).then((response) => {
        console.log(response)
        var task = document.getElementById("task-root-" + id);
        task.parentNode.removeChild(task);
        displayTask(taskName.value, id)
    })
}

function saveNote(eleID) {
    // temporary boxes
    var noteName = document.getElementById("noteName");
    var noteContent = document.getElementById("noteContent")
    var id = document.getElementById(eleID).dataset.noteid
    let options = {
        api : "database",
        function : "updateNote",
        data : {
            noteID : id,
            name : noteName.value,
            content : noteContent.value
        } 
    }

    API(options).then((response) => {
        console.log(response)
        // remove the old note
        var note = document.getElementById("note-root-" + id);
        note.parentNode.removeChild(note);
        displayNote(noteName.value, id);
    })


}


function handleTaskChange(eleID) {
    var task = document.getElementById(eleID);
    task.disabled = true; // prevent changes while saving
    var id = document.getElementById(eleID).dataset.taskid
    let options = {
        api : "database",
        function : "updateTask",
        data : {
            taskID : id,
            complete : 1,
            name : document.getElementById("checklbl-" + id).innerHTML
        } 
    }
    API(options).then((response) => {
        console.log(response)
        setTimeout(() => {
            var task = document.getElementById("task-root-" + id);
            task.parentNode.removeChild(task);
        }, 100)
    })

}

function locationSearch() {
    let zipcode = document.getElementById("zipcode");
    let city = document.getElementById("city");
    let cityName = city.value
    let options = {};
    if (zipcode.value != "") {
        options = {
            api : "weather",
            function : "lookupByZip",
            data : {
                zip : zipcode.value,
            }
        }
    } else if (city.value != "") {
        options = {
            api : "weather",
            function : "lookupByName",
            data : {
                name : cityName,
            }
        }
    }

    API(options).then((result) => {
        var weatherSearch = document.getElementById("weatherSearch");
        weatherSearch.innerHTML = "";
        zipcode.value = "";
        city.value = "";
        if (!result.error) {
            console.log(result)
            if (!Array.isArray(result)) {
                // convert to array
                let temp = result;
                result = [temp];
            }
            if(result.length == 0) {
                let message = "The location:<br>\"";
                message += cityName
                message += "\"<br>Could not be found. Please try again."
                weatherSearch.innerHTML = message;
            }
            
            result.forEach((location) => {
                var loc = document.createElement("p");
                var GWBtn = document.createElement("button");
                var locInfo = document.createElement("span")
                GWBtn.setAttribute("onclick", "getLocCurWeather(this.id)");
                GWBtn.setAttribute("data-loc_info", JSON.stringify(location))
                GWBtn.setAttribute("id", "loc-" + location.lat + "," + location.lon);
                GWBtn.innerText = "Get Weather";
                locInfo.innerHTML = location.name + "," + ((location.state != null) ? location.state + ",": "") + location.country
                loc.appendChild(GWBtn)
                loc.appendChild(locInfo)
                weatherSearch.appendChild(loc);
            })

        } else {
            let message = "The following error was encountered:<br>";
            message += result.message
            message += "<br>Please try again."
            weatherSearch.innerHTML = message;
        }
    })
}

function getLocCurWeather(id) {
    var location = JSON.parse(document.getElementById(id).dataset.loc_info);
    
    let request = {
        api : "weather", 
        function : "getCurWeather", 
        data : {
            lat : location.lat, 
            lon : location.lon
        }
    }

    
    API(request).then((result) => {
        // clear the search area
        var weatherSearch = document.getElementById("weatherSearch");
        //weatherSearch.innerHTML = "";
        if (!result.error) {
            var weatherRoot = document.getElementById("weatherRoot");
            weatherRoot.innerHTML = "";
            var title = document.createElement("h3");
            title.innerHTML = "Weather for " + location.name + "," + ((location.state != null) ? location.state + ",": "") + location.country
            weatherRoot.appendChild(title);

            console.log(result);

            let dataPoints = [
                {name : "Time", data : (new Date(result.dt*1000)).toLocaleString()},
                {name : "Current Temperature", data : result.main.temp + "F"},
                {name : "Feels Like", data : result.main.feels_like + "F"},
                {name : "Humidity", data : result.main.humidity + "%"},
                {name : "Wind Speed", data : result.wind.speed + "mph"},
                {name : "Description", data : result.weather[0].description},
                {name : "icon", data : `<img src="http://openweathermap.org/img/wn/` + result.weather[0].icon + `.png"/>`}
            ]
            var data_table = document.createElement("table");

            dataPoints.forEach((point) => {
                var row = document.createElement("tr")
                var name = document.createElement("td");
                var value = document.createElement("td");
                name.setAttribute("style", "text-align:right");
                value.setAttribute("style", "text-align:left")
                name.innerHTML = point.name + ":"
                value.innerHTML = point.data
                row.appendChild(name);
                row.appendChild(value);
                data_table.appendChild(row);
            })

            weatherRoot.appendChild(data_table)
        }
    })

}


function API(request) {
    return new Promise((resolve, reject) => {
        var options = {
            method : "POST",
            body : JSON.stringify(request)}
        fetch("api", options).then((response) => {
            return response.json()
        }).then((result) => {
            resolve(result);
        })
    })
}